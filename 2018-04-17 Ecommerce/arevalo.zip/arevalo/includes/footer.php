</main>

<div class="fullwidthdark">
<footer class="footer">
	<address class="address">142 10 St NW, Calgary, AB T2N 1V3 Canada</address>
	<p class="address">Mon - Sat 8:00 AM - 9:00 PM</p>
	<p class="address">Sun 9:00 AM - 5:00 PM</p>
	<p class="address">Call us at <span itemprop="telephone"><a href="tel:+15872417757">587-241-7757</a></span></p>
	<p class="address">&copy; 2008-2018, Hector A. Arevalo. All rights reserved.</p>
</footer>
</div>

<script src="script.js"></script>

</body>

</html>
